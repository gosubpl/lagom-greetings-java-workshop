# hello-lagom

A Hello World Lagom Java example
